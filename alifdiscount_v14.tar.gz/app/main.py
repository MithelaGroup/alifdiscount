from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

# ---- app
app = FastAPI(title="ALIF Discount")

# ---- session
SECRET = os.getenv("SECRET_KEY", "change-me")
app.add_middleware(SessionMiddleware, secret_key=SECRET, same_site="lax")

# ---- CORS (safe default)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"], allow_credentials=True
)

# ---- static & templates
BASE_DIR = Path(__file__).resolve().parents[1]
static_dir = BASE_DIR / "static"
static_dir.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

templates_dir = BASE_DIR / "templates"
templates_dir.mkdir(parents=True, exist_ok=True)
app.state.templates = Jinja2Templates(directory=str(templates_dir))  # used by views

# ---- health
@app.get("/healthz")
def healthz():
    return {"ok": True}

# include routers (after app is constructed so .state is ready)
from app.auth import router as auth_router  # noqa: E402
from app.views import router as views_router  # noqa: E402
app.include_router(auth_router)
app.include_router(views_router)

# Root alias (dashboard lives at "/")
@app.get("/dashboard")
def dashboard_alias():
    return RedirectResponse(url="/", status_code=307)
