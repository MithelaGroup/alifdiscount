from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Contact, CouponRequest, User
from app.utils import get_current_user, normalize_bd_mobile

BASE_DIR = Path(__file__).resolve().parents[1]
templates_fallback = Jinja2Templates(directory=str(BASE_DIR / "templates"))

router = APIRouter()

# ------------ helpers

def render(request: Request, template_name: str, context: dict):
    tmpl = getattr(request.app.state, "templates", templates_fallback)
    return tmpl.TemplateResponse(template_name, context)

def _require_login(request: Request, db: Session) -> User:
    user = get_current_user(request, db)
    if not user:
        # redirect to login preserving next
        next_url = request.url.path or "/"
        raise HTTPException(status_code=307, detail=f"/login?next={next_url}")
    return user

def _is_admin(user: User) -> bool:
    role = (user.role or "").upper()
    return role in {"ADMIN", "SUPERADMIN"}

def _display_name_and_mobile(r: CouponRequest) -> tuple[str, str]:
    # prefer linked contact; fallback to request copy
    name = ""
    mobile = ""
    if getattr(r, "contact", None):
        c = r.contact
        name = (getattr(c, "full_name", None) or getattr(c, "name", "") or "").strip()
        mobile = (getattr(c, "mobile", "") or "").strip()
    name = name or (getattr(r, "customer_name", "") or "")
    mobile = mobile or (getattr(r, "customer_mobile", "") or "")
    return name, mobile

# ------------ dashboard ("/")

@router.get("/")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login?next=/", status_code=307)

    base_q = select(CouponRequest).order_by(CouponRequest.created_at.desc())
    pending = db.execute(base_q.where(CouponRequest.status == "PENDING")).scalars().all()
    approved = db.execute(base_q.where(CouponRequest.status == "APPROVED")).scalars().all()
    done = db.execute(base_q.where(CouponRequest.status == "DONE")).scalars().all()

    def augment(rows):
        out = []
        for r in rows:
            name, mobile = _display_name_and_mobile(r)
            ref_u = getattr(r, "reference_user", None)
            out.append(
                {
                    "id": r.id,
                    "request_code": getattr(r, "request_code", ""),
                    "status": r.status,
                    "created_at": r.created_at,
                    "discount_percent": getattr(r, "discount_percent", None),
                    "invoice_number": getattr(r, "invoice_number", ""),
                    "customer_name": name,
                    "customer_mobile": mobile,
                    "reference_username": getattr(ref_u, "username", "") if ref_u else "",
                    "assigned_coupon_code": getattr(getattr(r, "assigned_coupon", None), "code", "") or "",
                }
            )
        return out

    ctx = {
        "request": request,
        "user": user,
        "pending": augment(pending),
        "approved": augment(approved),
        "done": augment(done),
        "can_act": _is_admin(user),
    }
    return render(request, "dashboard.html", ctx)

# ------------ Contacts

@router.get("/contacts")
def contacts_get(request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    items = db.execute(
        select(Contact).order_by(func.coalesce(Contact.full_name, Contact.name), Contact.id.asc())
    ).scalars().all()
    return render(request, "contacts.html", {"request": request, "user": user, "items": items})

@router.post("/contacts")
def contacts_add(
    request: Request,
    db: Session = Depends(get_db),
    full_name: str = Form(...),
    mobile: str = Form(...),
    notes: Optional[str] = Form(None),
):
    user = _require_login(request, db)
    m_norm = normalize_bd_mobile(mobile)
    c = Contact(full_name=full_name.strip(), name=full_name.strip(), mobile=m_norm, notes=(notes or "").strip())
    db.add(c)
    try:
        db.commit()
    except Exception:
        db.rollback()
    return RedirectResponse(url="/contacts", status_code=303)

# ------------ Requests

@router.get("/requests")
def requests_list(request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    rows = db.execute(select(CouponRequest).order_by(CouponRequest.created_at.desc())).scalars().all()

    out = []
    for r in rows:
        name, mobile = _display_name_and_mobile(r)
        ref_u = getattr(r, "reference_user", None)
        out.append(
            {
                "id": r.id,
                "request_code": getattr(r, "request_code", ""),
                "status": r.status,
                "created_at": r.created_at,
                "customer_name": name,
                "customer_mobile": mobile,
                "reference_username": getattr(ref_u, "username", "") if ref_u else "",
            }
        )

    return render(
        request, "requests.html", {"request": request, "user": user, "items": out, "can_act": _is_admin(user)}
    )

@router.get("/requests/new")
def request_new_get(request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    # reference dropdown = admins & superadmins
    refs = db.execute(
        select(User).where(User.role.in_(["ADMIN", "SUPERADMIN"])).order_by(User.username.asc())
    ).scalars().all()
    return render(request, "request_new.html", {"request": request, "user": user, "refs": refs})

@router.post("/requests/new")
def request_new_post(
    request: Request,
    db: Session = Depends(get_db),
    full_name: str = Form(...),
    mobile: str = Form(...),
    reference_user_id: int = Form(...),
    notes: str = Form(""),
):
    user = _require_login(request, db)
    # find or create Contact
    mobile_n = normalize_bd_mobile(mobile)
    contact = db.execute(select(Contact).where(Contact.mobile == mobile_n)).scalar_one_or_none()
    if not contact:
        contact = Contact(full_name=full_name.strip(), name=full_name.strip(), mobile=mobile_n)
        db.add(contact)
        db.flush()

    # build request
    cr = CouponRequest(
        contact_id=contact.id,
        customer_name=full_name.strip(),
        customer_mobile=mobile_n,
        reference_user_id=reference_user_id,
        notes=(notes or "").strip(),
        status="PENDING",
    )
    db.add(cr)
    db.commit()
    return RedirectResponse(url="/requests", status_code=303)

@router.post("/requests/{rid}/approve")
def request_approve(rid: int, request: Request, db: Session = Depends(get_db), discount_percent: Optional[int] = Form(None)):
    user = _require_login(request, db)
    if not _is_admin(user):
        raise HTTPException(status_code=403, detail="Not allowed")
    obj = db.get(CouponRequest, rid)
    if not obj:
        raise HTTPException(status_code=404, detail="Not found")
    obj.status = "APPROVED"
    if discount_percent is not None:
        try:
            obj.discount_percent = int(discount_percent)
        except Exception:
            pass
    db.add(obj)
    db.commit()
    return RedirectResponse(url=request.headers.get("referer", "/"), status_code=303)

@router.post("/requests/{rid}/reject")
def request_reject(rid: int, request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    if not _is_admin(user):
        raise HTTPException(status_code=403, detail="Not allowed")
    obj = db.get(CouponRequest, rid)
    if not obj:
        raise HTTPException(status_code=404, detail="Not found")
    obj.status = "REJECTED"
    db.add(obj)
    db.commit()
    return RedirectResponse(url=request.headers.get("referer", "/"), status_code=303)

@router.post("/requests/{rid}/done")
def request_done(
    rid: int,
    request: Request,
    db: Session = Depends(get_db),
    invoice_number: Optional[str] = Form(None),
):
    user = _require_login(request, db)
    if not _is_admin(user):
        raise HTTPException(status_code=403, detail="Not allowed")
    obj = db.get(CouponRequest, rid)
    if not obj:
        raise HTTPException(status_code=404, detail="Not found")
    obj.status = "DONE"
    if invoice_number:
        obj.invoice_number = invoice_number.strip()
    db.add(obj)
    db.commit()
    return RedirectResponse(url=request.headers.get("referer", "/"), status_code=303)

# ---- simple placeholders (menus present; implement later)
@router.get("/coupons")
def coupons_placeholder(request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    return render(request, "placeholder.html", {"request": request, "user": user, "title": "Coupons", "text": "Coming soon."})

@router.get("/users")
def users_placeholder(request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    return render(request, "placeholder.html", {"request": request, "user": user, "title": "Users", "text": "Coming soon."})

@router.get("/settings")
def settings_placeholder(request: Request, db: Session = Depends(get_db)):
    user = _require_login(request, db)
    return render(request, "placeholder.html", {"request": request, "user": user, "title": "Settings", "text": "Coming soon."})
