from __future__ import annotations

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.utils import verify_password, login_user, logout_user

router = APIRouter()

@router.get("/login")
def login_get(request: Request):
    next_url = request.query_params.get("next", "/")
    return request.app.state.templates.TemplateResponse(  # type: ignore[attr-defined]
        "login.html",
        {"request": request, "next": next_url, "error": None, "user": None},
    )

@router.post("/login")
def login_post(
    request: Request,
    db: Session = Depends(get_db),
    login: str = Form(...),
    password: str = Form(...),
    next: str = Form("/", alias="next"),
):
    # lookup by username OR email
    stmt = select(User).where((User.username == login) | (User.email == login))
    user = db.execute(stmt).scalar_one_or_none()
    if not user or not verify_password(password, user.password_hash):
        return request.app.state.templates.TemplateResponse(  # type: ignore[attr-defined]
            "login.html",
            {"request": request, "next": next, "error": "Invalid username or password.", "user": None},
            status_code=400,
        )

    login_user(request, user)
    return RedirectResponse(url=next or "/", status_code=303)

@router.get("/logout")
def logout(request: Request):
    logout_user(request)
    return RedirectResponse(url="/login", status_code=303)
